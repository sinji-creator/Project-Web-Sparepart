document.addEventListener('DOMContentLoaded', function() {
    const customDateInput = document.getElementById('customDateInput');
    const dateStatus = document.getElementById('dateStatus');
    const setDateBtn = document.getElementById('setDateBtn');
    const resetDateBtn = document.getElementById('resetDateBtn');

    async function loadCurrentDate() {
        try {
            const response = await fetch('/api/date/current');
            const data = await response.json();
            
            if (data.is_custom && data.custom_date) {
                customDateInput.value = data.custom_date;
                updateDateStatus(true, data.custom_date);
            } else {
                customDateInput.value = data.server_date;
                updateDateStatus(false, data.server_date);
            }
        } catch (error) {
            console.error('Error loading current date:', error);
            const today = new Date().toISOString().split('T')[0];
            customDateInput.value = today;
            updateDateStatus(false, today);
        }
    }

    function updateDateStatus(isCustom, date) {
        if (isCustom) {
            dateStatus.className = 'date-status custom-date';
            dateStatus.innerHTML = `<i class="fas fa-calendar-check"></i> <span class="status-text">Custom: ${formatDateDisplay(date)}</span>`;
        } else {
            dateStatus.className = 'date-status server-date';
            dateStatus.innerHTML = `<i class="fas fa-server"></i> <span class="status-text">Server Date</span>`;
        }
    }

    function formatDateDisplay(dateStr) {
        const date = new Date(dateStr);
        const day = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear().toString().slice(-2);
        return `${day}/${month}/${year}`;
    }

    if (setDateBtn) {
        setDateBtn.addEventListener('click', async function() {
            const selectedDate = customDateInput.value;
            
            if (!selectedDate) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Pilih Tanggal',
                    text: 'Silakan pilih tanggal terlebih dahulu'
                });
                return;
            }

            try {
                const response = await fetch('/api/date/set', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ date: selectedDate })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    updateDateStatus(true, selectedDate);
                    Swal.fire({
                        icon: 'success',
                        title: 'Tanggal Diubah',
                        text: `Semua transaksi akan menggunakan tanggal ${formatDateDisplay(selectedDate)}`,
                        timer: 2000,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: data.message
                    });
                }
            } catch (error) {
                console.error('Error setting date:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Terjadi kesalahan saat mengubah tanggal'
                });
            }
        });
    }

    if (resetDateBtn) {
        resetDateBtn.addEventListener('click', async function() {
            try {
                const response = await fetch('/api/date/reset', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    customDateInput.value = data.server_date;
                    updateDateStatus(false, data.server_date);
                    Swal.fire({
                        icon: 'success',
                        title: 'Tanggal Direset',
                        text: 'Transaksi akan menggunakan tanggal server',
                        timer: 2000,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: data.message
                    });
                }
            } catch (error) {
                console.error('Error resetting date:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Terjadi kesalahan saat mereset tanggal'
                });
            }
        });
    }

    loadCurrentDate();
});
