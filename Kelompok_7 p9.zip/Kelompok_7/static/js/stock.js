const historyTableBody = document.getElementById('historyTableBody');
const selectAllCheckbox = document.getElementById('select-all');
const deleteButton = document.getElementById('delete-selected-history-btn');
const selectionStatus = document.getElementById('selection-status');

async function loadHistory() {
    try {
        const response = await fetch('/api/stock/history');
        const history = await response.json();
        
        const tbody = document.getElementById('historyTableBody');
        
        if (history.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">Belum ada history</td></tr>';
            return;
        }  

        tbody.innerHTML = history.map(record => `
            <tr class="history-row">
                <td>${record.product_name}</td>
                <td style="text-align: center;">${record.quantity}</td>
                <td style="text-align: center;">${record.platform || 'Semua Platform'}</td>
                <td style="text-align: center;">${new Date(record.created_at).toLocaleString('id-ID')}</td> 
                <td style="text-align: center;">
                    <input type="checkbox" id="history-check-button-${record.id}" class="history-checkbox h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500" data-id="${record.id}">
                </td>
            </tr>
        `).join('');

        // Tambahkan event listener ke setiap checkbox untuk memperbarui status pemilihan
        const checkboxes = document.querySelectorAll('.history-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const row = checkbox.closest('.history-row');
                if (row) {
                    row.classList.toggle('selected', checkbox.checked);
                }
                updateControls();
            });
        });

        // Listener untuk event CLICK pada seluruh Baris (untuk memilih/membatalkan pilihan)
        const rows = document.querySelectorAll('#historyTableBody tr');
        rows.forEach(row => {
            row.addEventListener('click', (e) => {
                // Hindari toggle checkbox saat mengklik checkbox itu sendiri
                if (e.target.type !== 'checkbox') {
                    const checkbox = row.querySelector('.history-checkbox');
                    if (checkbox) {
                        checkbox.checked = !checkbox.checked;
                        row.classList.toggle('selected', checkbox.checked);
                        updateControls();
                    }
                }
            });
        });

        // Listener untuk checkbox all select agar 1 kotak kolom dapat aktif semua
        const boxSelectAll = document.getElementById('select-all-header');
        if (boxSelectAll) {
            boxSelectAll.addEventListener('click', (e) => {
                // Hindari toggle checkbox saat mengklik checkbox itu sendiri
                if (e.target.type !== 'checkbox') {
                    selectAllCheckbox.checked = !selectAllCheckbox.checked;
                    const isChecked = selectAllCheckbox.checked;
                    const checkboxes = document.querySelectorAll('.history-checkbox');
                    checkboxes.forEach(checkbox => {
                        checkbox.checked = isChecked;
                        const row = checkbox.closest('.history-row');
                        if (row) {
                            row.classList.toggle('selected', isChecked);
                        }
                    });
                    updateControls();
                }
            });
        }

        // Reset kontrol setelah memuat ulang data
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = false;
        updateControls();

    } catch (error) {
        console.error('Error loading history:', error);
    }
}

// Fungsi untuk memperbarui status kontrol (tombol hapus, hitungan)
function updateControls() {
    const checkboxes = document.querySelectorAll('.history-checkbox');
    const checkedCheckboxes = document.querySelectorAll('.history-checkbox:checked');
    const total = checkboxes.length;
    const checked = checkedCheckboxes.length;

    // Perbarui status tombol hapus
    deleteButton.disabled = checked === 0;

    // Perbarui status centang semua
    if (checked === 0) {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = false;
    } else if (checked === total) {
        selectAllCheckbox.checked = true;
        selectAllCheckbox.indeterminate = false;
    } else {
        selectAllCheckbox.indeterminate = true;
    }

    // Perbarui tampilan hitungan terpilih
    selectionStatus.textContent = `${checked} baris terpilih`;
}


if (selectAllCheckbox) {
    selectAllCheckbox.addEventListener('change', () => {
        const isChecked = selectAllCheckbox.checked;
        const checkboxes = document.querySelectorAll('.history-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = isChecked;
            const row = checkbox.closest('.history-row');
            if (row) {
                row.classList.toggle('selected', isChecked);
            }
        });
        updateControls();
    });
}


if (deleteButton && !deleteButton.hasAttribute('data-listener-attached')) {
    deleteButton.addEventListener('click', async () => {
        const checkedCheckboxes = document.querySelectorAll('.history-checkbox:checked');
        const idsToDelete = Array.from(checkedCheckboxes).map(cb => cb.getAttribute('data-id'));
        if (idsToDelete.length === 0) {
            return;
        }

        // Ganti confirm() dengan SweetAlert2
        const result = await Swal.fire({
            title: 'Hapus History?',
            text: `Apakah Anda yakin ingin menghapus ${idsToDelete.length} history terpilih? Tindakan ini tidak dapat dibatalkan.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, Hapus',
            cancelButtonText: 'Batal'
        });

        if (!result.isConfirmed) {
            return;
        }

        try {
            const response = await fetch('/api/stock/history/delete', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ids: idsToDelete })
            });
            
            const data = await response.json();
            
            if (data.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil Dihapus!',
                    text: data.message,
                    showConfirmButton: false,
                    timer: 2000
                });
                loadHistory();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal Dihapus!',
                    text: data.message,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Terjadi kesalahan. Silakan coba lagi.',
            });
        }
    });
    deleteButton.setAttribute('data-listener-attached', 'true');
}

// =================================================================
// FUNGSI MANAJEMEN STOK UTAMA
// =================================================================

async function loadStock(search = '') {
    try {
        const response = await fetch(`/api/stock?search=${encodeURIComponent(search)}`);
        const stocks = await response.json();
        
        const tbody = document.getElementById('stockTable');
        
        if (stocks.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">Belum ada data stok</td></tr>';
            return;
        }
        
        tbody.innerHTML = stocks.map(stock => `
            <tr>
                <td>${stock.name}</td>
                <td style="text-align: center;">${stock.shopee_stock}</td>
                <td style="text-align: center;">${stock.tokopedia_stock}</td>
                <td style="text-align: center;">${stock.lazada_stock}</td>
                <td style="text-align: center;"><strong>${stock.total_stock}</strong></td>
                <td style="text-align: center;" class="sticky-column">
                    <button class="btn btn-sm btn-info me-1 reduce-stock-btn" 
                            data-product-id="${stock.id}" 
                            data-product-name="${stock.name}" 
                            title="Kurangi Stok">
                        <i class="fas fa-minus"></i>
                    </button>
                    <button class="btn btn-sm btn-warning add-platform-stock-btn" 
                            data-product-id="${stock.id}" 
                            data-product-name="${stock.name}" 
                            title="Tambah Stok Platform">
                        <i class="fas fa-cubes"></i>
                    </button>
                </td>
            </tr>
        `).join('');

        // ✅ PERBAIKAN: Panggil fungsi untuk attach event listeners
        attachStockButtonListeners();
        
    } catch (error) {
        console.error('Error loading stock:', error);
    }
}

// ✅ FUNGSI BARU: Attach event listeners untuk tombol di tabel stok
function attachStockButtonListeners() {
    // Event listener untuk tombol "Kurangi Stok"
    document.querySelectorAll('.reduce-stock-btn').forEach(button => {
        button.addEventListener('click', () => {
            const productId = button.getAttribute('data-product-id');
            const productName = button.getAttribute('data-product-name');
            showReduceModal(productId, productName);
        });
    });

    // Event listener untuk tombol "Tambah Stok Platform"
    document.querySelectorAll('.add-platform-stock-btn').forEach(button => {
        button.addEventListener('click', () => {
            const productId = button.getAttribute('data-product-id');
            const productName = button.getAttribute('data-product-name');
            showAddPlatformModal(productId, productName);
        });
    });
}

// ✅ FUNGSI BARU: Tampilkan modal "Tambah Stok Platform"
function showAddPlatformModal(productId, productName) {
    const modal = document.getElementById('addStockPlatformModal');
    const modalTitle = document.getElementById('addStockPlatformModalLabel');
    const productIdInput = document.getElementById('platform_product_id');
    const productNameDisplay = document.getElementById('selected_product_name');
    
    // Set data ke modal
    if (productIdInput) productIdInput.value = productId;
    if (modalTitle) modalTitle.textContent = `Tambah Stok Platform untuk ${productName}`;
    if (productNameDisplay) productNameDisplay.textContent = productName;
    
    // Reset form
    const form = document.getElementById('addStockPlatformForm');
    if (form) form.reset();
    
    // Tampilkan modal
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
}

// Fungsi untuk menampilkan modal "Kurangi Stok"
function showReduceModal(productId, productName) {
    document.getElementById('reduce_product_id').value = productId;
    document.getElementById('reduce_product_name').value = productName;
    document.getElementById('reduce_quantity').value = '';
    document.getElementById('reduce_platform').value = '';
    
    const modal = new bootstrap.Modal(document.getElementById('reduceStockModal'));
    modal.show();
}

// ✅ Event listener untuk form "Tambah Stok Platform" (Modal Baru)
const addStockPlatformForm = document.getElementById('addStockPlatformForm');
if (addStockPlatformForm) {
    addStockPlatformForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const product_id = document.getElementById('platform_product_id').value;
        const platform = document.getElementById('platform_name').value;
        const quantity = document.getElementById('platform_quantity').value;
        
        try {
            const response = await fetch('/api/stock/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ product_id, platform, quantity })
            });
            
            const data = await response.json();
            
            if (data.success) {
                const modal = bootstrap.Modal.getInstance(document.getElementById('addStockPlatformModal'));
                if (modal) modal.hide();

                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: data.message,
                    showConfirmButton: false,
                    timer: 2000
                });
                
                addStockPlatformForm.reset();
                loadStock();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: data.message,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Terjadi kesalahan. Silakan coba lagi.',
            });
        }
    });
}

// Event listener untuk form "Kurangi Stok"
const reduceStockForm = document.getElementById('reduceStockForm');
if (reduceStockForm) {
    reduceStockForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const product_id = document.getElementById('reduce_product_id').value;
        const quantity = document.getElementById('reduce_quantity').value;
        const platform = document.getElementById('reduce_platform').value;
        
        try {
            const response = await fetch('/api/stock/reduce', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    product_id, 
                    quantity, 
                    platform: platform || null
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                const modal = bootstrap.Modal.getInstance(document.getElementById('reduceStockModal'));
                if (modal) modal.hide();

                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: data.message,
                    showConfirmButton: false,
                    timer: 2000
                });
                
                reduceStockForm.reset();
                loadStock();
                loadHistory();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: data.message,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Terjadi kesalahan. Silakan coba lagi.',
            });
        }
    });
}

// Event listener untuk search input
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value;
        loadStock(query);
    });
}


loadStock();
loadHistory();


document.addEventListener("DOMContentLoaded", () => {
    const modalEl = document.getElementById("historyModal");

    if (modalEl) {
        modalEl.addEventListener("hidden.bs.modal", () => {
            if (document.activeElement) {
                document.activeElement.blur();
            }
            document.body.focus();
        });
    }
});