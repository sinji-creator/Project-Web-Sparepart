async function loadSummary() {
    try {
        const response = await fetch('/api/summary');
        const data = await response.json();
        
        document.getElementById('totalSales').textContent = `${data.total_sales} Unit`;
        document.getElementById('totalRevenue').textContent = `Rp ${data.total_revenue.toLocaleString('id-ID')}`;
        
        const tbody = document.getElementById('topProductsTable');
        
        if (data.top_products.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">Belum ada data penjualan</td></tr>';
        } else {
            tbody.innerHTML = data.top_products.map((product, index) => `
                <tr>
                    <td><strong>${index + 1}</strong></td>
                    <td>${product.name}</td>
                    <td>${product.units_sold}</td>
                    <td>Rp ${parseFloat(product.revenue).toLocaleString('id-ID')}</td>
                    <td>${product.best_platform || '-'}</td>
                </tr>
            `).join('');
        }
        
        const platformMap = {
            'Shopee': 0,
            'Tokopedia': 0,
            'Lazada': 0
        };
        
        data.platform_distribution.forEach(p => {
            platformMap[p.platform] = p.units_sold;
        });
        
        document.getElementById('shopeeUnits').textContent = `${platformMap['Shopee']} unit`;
        document.getElementById('tokopediaUnits').textContent = `${platformMap['Tokopedia']} unit`;
        document.getElementById('lazadaUnits').textContent = `${platformMap['Lazada']} unit`;
        
    } catch (error) {
        console.error('Error loading summary:', error);
    }
}

loadSummary();