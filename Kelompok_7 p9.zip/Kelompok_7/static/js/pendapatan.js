let platformChart, trendChart;

async function loadRevenue(period = 'month') {
    try {
        const response = await fetch(`/api/sales/revenue?period=${period}`);
        const data = await response.json();
        
        const totalRevenue = data.platform_revenue.reduce((sum, p) => sum + parseFloat(p.total_revenue), 0);
        document.getElementById('totalRevenue').textContent = `Rp ${totalRevenue.toLocaleString('id-ID')}`;
        
        if (platformChart) {
            platformChart.destroy();
        }
        
        const platformCtx = document.getElementById('platformChart').getContext('2d');
        platformChart = new Chart(platformCtx, {
            type: 'bar',
            data: {
                labels: data.platform_revenue.map(p => p.platform),
                datasets: [{
                    label: 'Pendapatan (Rp)',
                    data: data.platform_revenue.map(p => parseFloat(p.total_revenue)),
                    backgroundColor: [
                        'rgba(38, 208, 168, 0.7)',
                        'rgba(52, 211, 153, 0.7)',
                        'rgba(16, 185, 129, 0.7)'
                    ],
                    borderColor: [
                        'rgba(38, 208, 168, 1)',
                        'rgba(52, 211, 153, 1)',
                        'rgba(16, 185, 129, 1)'
                    ],
                    borderWidth: 2,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });
        
        if (trendChart) {
            trendChart.destroy();
        }
        
        const trendCtx = document.getElementById('trendChart').getContext('2d');
        const trendData = data.trend_data.reverse();
        
        trendChart = new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: trendData.map(d => {
                    const date = new Date(d.period);
                    if (period === 'month') {
                        return date.toLocaleDateString('id-ID', { year: 'numeric', month: 'short' });
                    } else {
                        return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
                    }
                }),
                datasets: [{
                    label: 'Pendapatan',
                    data: trendData.map(d => parseFloat(d.total_revenue)),
                    borderColor: 'rgba(38, 208, 168, 1)',
                    backgroundColor: 'rgba(38, 208, 168, 0.15)',
                    fill: true,
                
                    // === Kurva Smooth ===
                    tension: 0.55,
                    cubicInterpolationMode: 'monotone',
                
                    borderWidth: 3,
                
                    // Titik lebih kecil biar chart terlihat bersih
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    pointBackgroundColor: 'rgba(38, 208, 168, 1)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error loading revenue:', error);
    }
}

document.getElementById('periodFilter').addEventListener('change', (e) => {
    loadRevenue(e.target.value);
});

loadRevenue();
