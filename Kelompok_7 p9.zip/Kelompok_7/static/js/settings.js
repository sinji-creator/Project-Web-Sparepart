// ===============================
// RESET_DATA.JS (Logika untuk Reset Data)
// ===============================

document.addEventListener('DOMContentLoaded', async function() {

    // Semua tombol pemicu reset
    const actionButtonIds = ['resetDataBtn', 'resetDataSidebarBtn'];

    // -----------------------------
    // 1. CEK APAKAH DATA KOSONG
    // -----------------------------
    let dataKosong = true;
    try {
        const res = await fetch('/api/data/check');
        const json = await res.json();
        dataKosong = json.total_data === 0;  // jika 0 → kosong
    } catch (e) {
        console.error("Gagal cek data:", e);
    }

    // -----------------------------
    // 2. SET STATUS BUTTON (disable jika data kosong)
    // -----------------------------
    actionButtonIds.forEach(id => {
        const button = document.getElementById(id);
        if (!button) return;

        if (dataKosong) {
            button.classList.add("disabled-reset-btn");
            button.style.opacity = "0.5";
            button.style.pointerEvents = "none";
            button.style.cursor = "not-allowed";
            button.title = "Tidak ada data untuk di-reset";
        }
    });

    // Jika data kosong → stop sampai sini
    if (dataKosong) return;

    // -----------------------------
    // 3. HANYA JALANKAN KONFIRMASI JIKA ADA DATA
    // -----------------------------
    actionButtonIds.forEach(id => {
        const button = document.getElementById(id);

        if (button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Yakin Ingin Reset Data?',
                    text: "Anda tidak akan dapat mengembalikan data ini! Semua produk, stok, dan transaksi akan dihapus.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#DC3545',
                    cancelButtonColor: '#6C757D',
                    confirmButtonText: 'Ya, Hapus Permanen!',
                    cancelButtonText: 'Batal'
                }).then(async (result) => {

                    if (result.isConfirmed) {
                        Swal.fire({
                            title: 'Memproses...',
                            text: 'Sedang menghapus data Anda, mohon tunggu.',
                            allowOutsideClick: false,
                            didOpen: () => Swal.showLoading()
                        });

                        try {
                            const response = await fetch('/api/data/reset', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' }
                            });

                            const data = await response.json();

                            if (data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil Direset!',
                                    text: data.message
                                }).then(() => window.location.reload());
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal!',
                                    text: data.message || 'Gagal mereset data.'
                                });
                            }
                        } catch (err) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error Jaringan!',
                                text: 'Terjadi kesalahan jaringan.'
                            });
                        }

                    }
                });
            });
        }
    });

});
