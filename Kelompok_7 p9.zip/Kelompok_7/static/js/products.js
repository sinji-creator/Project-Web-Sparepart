async function loadProducts(search = '') {
    try {
        const response = await fetch(`/api/products?search=${encodeURIComponent(search)}`);
        const products = await response.json();
        
        const tbody = document.getElementById('productsTable');
        
        if (products.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center">Belum ada produk. Tambahkan produk pertama Anda!</td></tr>';
            return;
        }
        
        tbody.innerHTML = products.map(product => `
            <tr>
                <td>${product.name}</td>
                <td>Rp ${parseFloat(product.price).toLocaleString('id-ID')}</td>
                <td>
                    <button class="btn-delete" onclick="deleteProduct(${product.id})">
                        <i class="fas fa-trash"></i> Hapus
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

document.getElementById('addProductForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('product_name').value;
    const price = document.getElementById('product_price').value;
    
    try {
        const response = await fetch('/api/products', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, price })
        });
        
        const data = await response.json();
        
        if (data.success) {
            const modal = bootstrap.Modal.getInstance(document.getElementById('addProductModal'));
            modal.hide();
            document.getElementById('addProductForm').reset();
            loadProducts();
            alert('Produk berhasil ditambahkan!');
        } else {
            alert(data.message);
        }
    } catch (error) {
        alert('Terjadi kesalahan. Silakan coba lagi.');
    }
});

async function deleteProduct(id) {
    if (!confirm('Yakin ingin menghapus produk ini?')) return;
    
    try {
        const response = await fetch(`/api/products/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadProducts();
            alert('Produk berhasil dihapus!');
        } else {
            alert(data.message);
        }
    } catch (error) {
        alert('Terjadi kesalahan. Silakan coba lagi.');
    }
}

document.getElementById('searchInput').addEventListener('input', (e) => {
    const query = e.target.value;
    loadProducts(query);
});


loadProducts();
