﻿from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from datetime import datetime
from functools import wraps


app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET', 'dev-secret-key-change-in-production')

def get_db_connection():
    """Create SQLite database connection"""
    os.makedirs('data', exist_ok=True)
    conn = sqlite3.connect('data/toko_database.db', detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES)
    conn.row_factory = sqlite3.Row
    # Enforce foreign keys
    conn.execute('PRAGMA foreign_keys = ON')
    return conn

def get_transaction_timestamp():
    """
    Mengambil tanggal transaksi (kustom dari session atau tanggal server saat ini) 
    dan mengembalikannya sebagai string format 'YYYY-MM-DD HH:MM:SS' untuk SQLite.
    """
    format_str = '%Y-%m-%d %H:%M:%S'
    
    if 'custom_date' in session and session['custom_date']:
        custom_date_str = session['custom_date'] # YYYY-MM-DD
        
        # Menggabungkan tanggal kustom dengan waktu saat ini (jam, menit, detik) dari server
        now = datetime.now()
        full_datetime = datetime.strptime(custom_date_str, '%Y-%m-%d').replace(
            hour=now.hour, 
            minute=now.minute, 
            second=now.second, 
            microsecond=0
        )
        return full_datetime.strftime(format_str)
    
    # Jika tidak ada tanggal kustom, gunakan tanggal dan waktu server saat ini
    return datetime.now().strftime(format_str)
# -----------------------------

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def init_db():
    conn = get_db_connection()
    cur = conn.cursor()
    
    # Create tables
    cur.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(100) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )''')
    
    cur.execute('''CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(255) NOT NULL,
            price DECIMAL(12, 2) NOT NULL,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )''')
    
    cur.execute('''CREATE TABLE IF NOT EXISTS stock_platforms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
            platform VARCHAR(50) NOT NULL,
            quantity INTEGER DEFAULT 0,
            UNIQUE(product_id, platform)
        )''')
    
    cur.execute('''CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
            platform VARCHAR(50),
            quantity INTEGER NOT NULL,
            total_amount DECIMAL(12, 2) NOT NULL,
            sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE
        )''')
    
    cur.execute('''CREATE TABLE IF NOT EXISTS stock_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
            platform VARCHAR(50),
            transaction_type VARCHAR(20) NOT NULL,
            quantity INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE
        )''')
        
    
    # Create default admin user if not exists
    cur.execute("SELECT COUNT(*) as count FROM users")
    user_count = cur.fetchone()[0]
    
    if user_count == 0:
        hashed_password = generate_password_hash('admin123')
        cur.execute(
            'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
            ('admin', 'admin@toko.com', hashed_password)
        )
        print("INFO: Default user created - username: admin, password: admin123")
    
    conn.commit()
    cur.close()
    conn.close()
    print("SUCCESS: Database initialized successfully")

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.get_json() or request.form
        username = data.get('username')
        password = data.get('password')
        
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = cur.fetchone()
        cur.close()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['email'] = user['email']
            return jsonify({'success': True, 'message': 'Login berhasil'})
        else:
            return jsonify({'success': False, 'message': 'Username atau password salah'})
    
    # Render login page (including logic to show flash messages)
    return render_template('login.html')

@app.route('/registrasikelompok708557884754', methods=['GET'])
def signup():
    """Rute untuk menampilkan halaman pendaftaran"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('signup.html')


@app.route('/register', methods=['POST'])
def register():
    """
    Rute yang dimodifikasi untuk menangani form submission dari halaman /signup
    dan menggunakan Flask flash messages + redirect.
    """
    # Menggunakan request.form karena ini adalah form submission standar
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    
    if not username or not email or not password:
        flash('Semua field (Username, Email, Password) harus diisi.', 'error')
        return redirect(url_for('signup'))
    
    hashed_password = generate_password_hash(password)
    
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                    (username, email, hashed_password))
        conn.commit()
        cur.close()
        conn.close()
        
        flash('Registrasi berhasil! Silakan login menggunakan akun Anda.', 'success')
        return redirect(url_for('login'))
        
    except sqlite3.IntegrityError:
        flash('Username atau email sudah terdaftar. Gunakan yang lain.', 'error')
        return redirect(url_for('signup'))
    except Exception as e:
        flash(f'Terjadi kesalahan saat registrasi: {e}', 'error')
        return redirect(url_for('signup'))


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    user_id = session['user_id']
    conn = get_db_connection()
    cur = conn.cursor()
    
    cur.execute('SELECT COUNT(*) as total FROM products WHERE user_id = ?', (user_id,))
    total_products = cur.fetchone()[0]
    
    cur.execute('''
        SELECT COALESCE(SUM(quantity), 0) as total 
        FROM stock_platforms sp
        JOIN products p ON sp.product_id = p.id
        WHERE p.user_id = ?
    ''', (user_id,))
    total_stock = cur.fetchone()[0]
    
    # -----------------------------
    # FIXED: Use only sales without custom date filtering on dashboard summary
    # -----------------------------
    cur.execute('''
        SELECT COALESCE(SUM(total_amount), 0) as total 
        FROM sales 
        WHERE user_id = ?
    ''', (user_id,))
    total_revenue = cur.fetchone()[0]
    
    cur.execute('''
        SELECT COALESCE(SUM(quantity), 0) as total 
        FROM sales 
        WHERE user_id = ?
    ''', (user_id,))
    total_sold = cur.fetchone()[0]
    # -----------------------------
    
    cur.close()
    conn.close()
    
    return render_template('dashboard.html', 
                          total_products=total_products,
                          total_stock=total_stock,
                          total_revenue=float(total_revenue),
                          total_sold=total_sold)

@app.route('/products')
@login_required
def products():
    return render_template('products.html')

@app.route('/api/products', methods=['GET'])
@login_required
def get_products():
    user_id = session['user_id']
    search = request.args.get('search', '')

    conn = get_db_connection()
    cur = conn.cursor()
    if search :
        cur.execute('SELECT * FROM products WHERE user_id = ? AND name LIKE ? ORDER BY created_at DESC', (user_id, f'%{search}%'))
    else:
        cur.execute('SELECT * FROM products WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
    products = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify([dict(product) for product in products])

@app.route('/api/products', methods=['POST'])
@login_required
def add_product():
    data = request.get_json() or request.form
    name = data.get('name')
    price = data.get('price')
    user_id = session['user_id']
    
    if not name or price is None:
        return jsonify({'success': False, 'message': 'Nama dan harga harus diisi'})
    
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO products (name, price, user_id) VALUES (?, ?, ?)',
               (name, price, user_id))
    product_id = cur.lastrowid
    conn.commit()
    cur.close()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Produk berhasil ditambahkan', 'product_id': product_id})

@app.route('/api/products/<int:product_id>', methods=['DELETE'])
@login_required
def delete_product(product_id):
    user_id = session['user_id']
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM products WHERE id = ? AND user_id = ?', (product_id, user_id))
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'success': True, 'message': 'Produk berhasil dihapus'})

@app.route('/stock')
@login_required
def stock():
    return render_template('stock.html')

@app.route('/api/stock', methods=['GET'])
@login_required
def get_stock():
    user_id = session['user_id']
    search = request.args.get('search', '')

    conn = get_db_connection()
    cur = conn.cursor()
    
    if search:
        cur.execute('''
            SELECT 
                p.id,
                p.name,
                p.price,
                COALESCE(SUM(CASE WHEN sp.platform = 'Shopee' THEN sp.quantity ELSE 0 END), 0) as shopee_stock,
                COALESCE(SUM(CASE WHEN sp.platform = 'Tokopedia' THEN sp.quantity ELSE 0 END), 0) as tokopedia_stock,
                COALESCE(SUM(CASE WHEN sp.platform = 'Lazada' THEN sp.quantity ELSE 0 END), 0) as lazada_stock,
                COALESCE(SUM(sp.quantity), 0) as total_stock
            FROM products p
            LEFT JOIN stock_platforms sp ON p.id = sp.product_id
            WHERE p.user_id = ? AND p.name LIKE ?
            GROUP BY p.id, p.name, p.price
            ORDER BY p.name
        ''', (user_id, f'%{search}%'))
    else:
        cur.execute('''
            SELECT 
                p.id,
                p.name,
                p.price,
                COALESCE(SUM(CASE WHEN sp.platform = 'Shopee' THEN sp.quantity ELSE 0 END), 0) as shopee_stock,
                COALESCE(SUM(CASE WHEN sp.platform = 'Tokopedia' THEN sp.quantity ELSE 0 END), 0) as tokopedia_stock,
                COALESCE(SUM(CASE WHEN sp.platform = 'Lazada' THEN sp.quantity ELSE 0 END), 0) as lazada_stock,
                COALESCE(SUM(sp.quantity), 0) as total_stock
            FROM products p
            LEFT JOIN stock_platforms sp ON p.id = sp.product_id
            WHERE p.user_id = ?
            GROUP BY p.id, p.name, p.price
            ORDER BY p.name
        ''', (user_id,))
    
    stocks = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify([dict(stock) for stock in stocks])

@app.route('/api/stock/add', methods=['POST'])
@login_required
def add_stock():
    data = request.get_json() or request.form
    product_id = data.get('product_id')
    platform = data.get('platform')
    quantity = data.get('quantity')
    user_id = session['user_id']
    
    if not product_id or not platform or not quantity:
        return jsonify({'success': False, 'message': 'Semua field harus diisi'})
    
    try:
        quantity = int(quantity)
    except (ValueError, TypeError):
        return jsonify({'success': False, 'message': 'Quantity harus angka'})
    
    conn = get_db_connection()
    cur = conn.cursor()
    
    # -----------------------------
    # NEW: Get transaction date/timestamp
    # -----------------------------
    transaction_timestamp = get_transaction_timestamp()
    # -----------------------------
    
    cur.execute('''
        INSERT INTO stock_platforms (product_id, platform, quantity)
        VALUES (?, ?, ?)
        ON CONFLICT (product_id, platform)
        DO UPDATE SET quantity = stock_platforms.quantity + excluded.quantity
    ''', (product_id, platform, quantity))
    
    # -----------------------------
    # MODIFIED: Include created_at and use transaction_timestamp
    # -----------------------------
    cur.execute('''
        INSERT INTO stock_transactions (product_id, platform, transaction_type, quantity, user_id, created_at)
        VALUES (?, ?, 'add', ?, ?, ?)
    ''', (product_id, platform, quantity, user_id, transaction_timestamp))
    # -----------------------------
    
    conn.commit()
    cur.close()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Stok berhasil ditambahkan'})

@app.route('/api/stock/reduce', methods=['POST'])
@login_required
def reduce_stock():
    data = request.get_json() or request.form
    product_id = data.get('product_id')
    platform = data.get('platform')
    quantity = data.get('quantity')
    user_id = session['user_id']
    
    if not product_id or not quantity:
        return jsonify({'success': False, 'message': 'Product dan quantity harus diisi'})
    
    try:
        quantity = int(quantity)
        if quantity <= 0:
            return jsonify({'success': False, 'message': 'Quantity harus lebih besar dari 0'})
    except (ValueError, TypeError):
        return jsonify({'success': False, 'message': 'Quantity harus berupa angka positif'})
    
    conn = get_db_connection()
    cur = conn.cursor()
    
    # -----------------------------
    # NEW: Get transaction date/timestamp
    # -----------------------------
    transaction_timestamp = get_transaction_timestamp()
    # -----------------------------
    
    cur.execute('SELECT price FROM products WHERE id = ? AND user_id = ?', (product_id, user_id))
    product = cur.fetchone()
    if not product:
        cur.close()
        conn.close()
        return jsonify({'success': False, 'message': 'Produk tidak ditemukan atau Anda tidak memiliki akses'})
    
    price = product['price']
    
    if platform:
        cur.execute('''
            UPDATE stock_platforms 
            SET quantity = quantity - ? 
            WHERE product_id = ? 
            AND platform = ? 
            AND quantity >= ?
        ''', (quantity, product_id, platform, quantity))
        
        if cur.rowcount == 0:
            cur.close()
            conn.close()
            return jsonify({'success': False, 'message': 'Stok tidak cukup atau Anda tidak memiliki akses'})
        
        total_amount = float(price) * int(quantity)
        # -----------------------------
        # MODIFIED: Include sale_date and use transaction_timestamp
        # -----------------------------
        cur.execute('''
            INSERT INTO sales (product_id, platform, quantity, total_amount, user_id, sale_date)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (product_id, platform, quantity, total_amount, user_id, transaction_timestamp))

        cur.execute('''
            INSERT INTO stock_transactions (product_id, platform, transaction_type, quantity, user_id, created_at)
            VALUES (?, ?, 'reduce_sale', ?, ?, ?)
        ''', (product_id, platform, quantity, user_id, transaction_timestamp))
        # -----------------------------
        
        message = f'Stok berhasil dikurangi dari {platform} dan dihitung sebagai pendapatan'
    else:
        cur.execute('''
            SELECT sp.platform, sp.quantity 
            FROM stock_platforms sp
            JOIN products p ON sp.product_id = p.id
            WHERE sp.product_id = ? 
            AND sp.quantity > 0
            AND p.user_id = ?
            ORDER BY sp.quantity DESC
        ''', (product_id, user_id))
        
        available_stocks = cur.fetchall()
        remaining_qty = quantity
        
        for stock in available_stocks:
            if remaining_qty <= 0:
                break
            
            stock_platform = stock['platform']
            available = stock['quantity']
            to_reduce = min(remaining_qty, available)
            
            cur.execute('''
                UPDATE stock_platforms 
                SET quantity = quantity - ? 
                WHERE product_id = ? AND platform = ?
            ''', (to_reduce, product_id, stock_platform))
            
            remaining_qty -= to_reduce
        
        if remaining_qty > 0:
            conn.rollback()
            cur.close()
            conn.close()
            return jsonify({'success': False, 'message': 'Stok tidak cukup'})
        
        # -----------------------------
        # MODIFIED: Include created_at and use transaction_timestamp
        # -----------------------------
        cur.execute('''
            INSERT INTO stock_transactions (product_id, platform, transaction_type, quantity, user_id, created_at)
            VALUES (?, NULL, 'reduce_no_sale', ?, ?, ?)
        ''', (product_id, quantity, user_id, transaction_timestamp))
        # -----------------------------
        
        message = 'Stok berhasil dikurangi tanpa menghitung pendapatan'
    
    conn.commit()
    cur.close()
    conn.close()
    
    return jsonify({'success': True, 'message': message})

# -----------------------------
# NEW: DATE CONTROL API ENDPOINTS
# -----------------------------
@app.route('/api/date/current', methods=['GET'])
@login_required
def get_current_date():
    """Mengembalikan tanggal transaksi yang sedang aktif (server atau kustom)"""
    server_date_obj = datetime.now()
    server_date_str = server_date_obj.strftime('%Y-%m-%d')
    
    is_custom = 'custom_date' in session and session['custom_date'] is not None
    custom_date = session.get('custom_date')

    # Mengembalikan data sesuai format yang diharapkan oleh date-control.js
    return jsonify({
        'is_custom': is_custom,
        'custom_date': custom_date if is_custom else None,
        'server_date': server_date_str
    })

@app.route('/api/date/set', methods=['POST'])
@login_required
def set_custom_date():
    """Mengatur tanggal transaksi kustom ke dalam session"""
    data = request.get_json()
    new_date = data.get('date') # Format YYYY-MM-DD

    if not new_date:
        return jsonify({'success': False, 'message': 'Tanggal harus diisi'}), 400

    try:
        # Validasi format tanggal
        datetime.strptime(new_date, '%Y-%m-%d')
        session['custom_date'] = new_date
        
        return jsonify({
            'success': True, 
            'message': 'Tanggal transaksi berhasil diubah', 
            'custom_date': new_date
        })
    except ValueError:
        return jsonify({'success': False, 'message': 'Format tanggal tidak valid (harus YYYY-MM-DD)'}), 400

@app.route('/api/date/reset', methods=['POST'])
@login_required
def reset_custom_date():
    """Menghapus tanggal kustom dari session, kembali ke tanggal server"""
    session.pop('custom_date', None)
    
    server_date = datetime.now().strftime('%Y-%m-%d')
    
    return jsonify({
        'success': True, 
        'message': 'Tanggal transaksi berhasil direset', 
        'server_date': server_date
    })
# -----------------------------


@app.route('/api/stock/history', methods=['GET'])
@login_required
def history():
    user_id = session['user_id']
    
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('''
        SELECT 
            s.id,
            p.name as product_name,
            s.platform,
            s.quantity,
            DATETIME(s.sale_date, '+7 hours') as created_at
        FROM sales s
        JOIN products p ON s.product_id = p.id
        WHERE s.user_id = ? AND s.platform IS NOT NULL
        ORDER BY s.sale_date DESC
        LIMIT 100
    ''', (user_id,))
    
    history = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify([dict(record) for record in history])

@app.route('/api/stock/history/delete', methods=['POST'])
@login_required
def delete_history():
    user_id = session['user_id']
    ids = request.json.get('ids', [])

    if not ids:
        return jsonify({'success': False, 'message': 'No history IDs provided'})

    conn = get_db_connection()
    cur = conn.cursor()

    try:
        cur.execute(f'''
            DELETE FROM sales
            WHERE id IN ({','.join('?' for _ in ids)}) AND user_id = ?
        ''', (*ids, user_id))
        conn.commit()
        return jsonify({'success': True, 'message': f'{cur.rowcount} data history berhasil dihapus'})
    except Exception as e:
        conn.rollback()
        return jsonify({'success': False, 'message': str(e)})
    finally:
        cur.close()
        conn.close()

@app.route('/pendapatan')
@login_required
def pendapatan():
    return render_template('pendapatan.html')

@app.route('/api/sales/revenue', methods=['GET'])
@login_required
def get_revenue():
    user_id = session['user_id']
    period = request.args.get('period', 'month')
    
    conn = get_db_connection()
    cur = conn.cursor()
    
    # 1. Platform Revenue (Diurutkan berdasarkan total_revenue secara DESC)
    cur.execute('''
        SELECT 
            platform,
            COALESCE(SUM(total_amount), 0) as total_revenue
        FROM sales
        WHERE user_id = ? AND platform IS NOT NULL
        GROUP BY platform
        ORDER BY total_revenue DESC
    ''', (user_id,))
    
    platform_revenue = cur.fetchall()
    
    # 2. Trend Data
    if period == 'month':
        cur.execute('''
            SELECT 
                strftime('%Y-%m', sale_date) as period,
                COALESCE(SUM(total_amount), 0) as total_revenue
            FROM sales
            WHERE user_id = ? AND platform IS NOT NULL
            GROUP BY strftime('%Y-%m', sale_date)
            ORDER BY period DESC
            LIMIT 12
        ''', (user_id,))
    else:
        cur.execute('''
            SELECT 
                date(sale_date) as period,
                COALESCE(SUM(total_amount), 0) as total_revenue
            FROM sales
            WHERE user_id = ? AND platform IS NOT NULL
            GROUP BY date(sale_date)
            ORDER BY period DESC
            LIMIT 30
        ''', (user_id,))
    
    trend_data = cur.fetchall()
    
    cur.close()
    conn.close()
    
    return jsonify({
        'platform_revenue': [dict(item) for item in platform_revenue],
        'trend_data': [dict(item) for item in trend_data]
    })

@app.route('/summary')
@login_required
def summary():
    return render_template('summary.html')

@app.route('/api/summary', methods=['GET'])
@login_required
def get_summary():
    user_id = session['user_id']
    conn = get_db_connection()
    cur = conn.cursor()

    # TOTAL UNIT TERJUAL
    cur.execute('''
        SELECT COALESCE(SUM(quantity), 0) 
        FROM sales
        WHERE user_id = ?
    ''', (user_id,))
    total_sales = cur.fetchone()[0]

    # TOTAL REVENUE
    cur.execute('''
        SELECT COALESCE(SUM(total_amount), 0)
        FROM sales
        WHERE user_id = ?
    ''', (user_id,))
    total_revenue = cur.fetchone()[0]

    # TOP 10 PRODUK TERLARIS (berdasarkan qty)
    cur.execute('''
        SELECT 
            p.id,
            p.name,
            COALESCE(SUM(s.quantity), 0) AS units_sold,
            COALESCE(SUM(s.total_amount), 0) AS revenue
        FROM products p
        LEFT JOIN sales s ON p.id = s.product_id
        WHERE p.user_id = ?
        GROUP BY p.id, p.name
        ORDER BY units_sold DESC
        LIMIT 10
    ''', (user_id,))
    top_products_raw = cur.fetchall()

    # PLATFORM TERLARIS UNTUK SETIAP PRODUK
    top_products = []
    for prod in top_products_raw:
        prod_id = prod["id"]

        cur.execute('''
            SELECT 
                platform,
                SUM(quantity) as qty
            FROM sales
            WHERE product_id = ? AND user_id = ? AND platform IS NOT NULL
            GROUP BY platform
            ORDER BY qty DESC
            LIMIT 1
        ''', (prod_id, user_id))

        platform_data = cur.fetchone()

        top_products.append({
            "id": prod["id"],
            "name": prod["name"],
            "units_sold": prod["units_sold"],
            "revenue": prod["revenue"],
            "best_platform": platform_data["platform"] if platform_data else "-"
        })

    # PLATFORM TERLARIS SECARA UMUM
    cur.execute('''
        SELECT 
            platform,
            SUM(quantity) as units_sold
        FROM sales
        WHERE user_id = ? AND platform IS NOT NULL
        GROUP BY platform
        ORDER BY units_sold DESC
    ''', (user_id,))
    platform_distribution = cur.fetchall()

    cur.close()
    conn.close()

    return jsonify({
        "total_sales": total_sales,
        "total_revenue": float(total_revenue),
        "top_products": top_products,
        "platform_distribution": [dict(row) for row in platform_distribution]
    })

@app.route('/api/data/reset', methods=['POST'])
@login_required
def reset_data():
    """Endpoint API untuk menghapus semua data transaksi dan produk pengguna."""
    user_id = session['user_id']
    conn = get_db_connection()
    cur = conn.cursor()
    
    try:
        # 1. Hapus semua transaksi stok milik user
        cur.execute('DELETE FROM stock_transactions WHERE user_id = ?', (user_id,))
        
        # 2. Hapus semua penjualan milik user
        cur.execute('DELETE FROM sales WHERE user_id = ?', (user_id,))
        
        # 3. Hapus semua produk milik user. Ini akan memicu penghapusan data di 
        #    stock_platforms (melalui FOREIGN KEY ON DELETE CASCADE pada product_id).
        #    *Catatan: Akun pengguna di tabel 'users' TIDAK dihapus.*
        cur.execute('DELETE FROM products WHERE user_id = ?', (user_id,))
        
        conn.commit()
        
        return jsonify({'success': True, 'message': 'Semua data produk, stok, dan transaksi berhasil direset! Data akun Anda (username, password) tetap tersimpan.'})
        
    except Exception as e:
        conn.rollback()
        print(f"Error reset data: {e}")
        return jsonify({'success': False, 'message': 'Gagal mereset data. Silakan coba lagi.'})
    finally:
        cur.close()
        conn.close()

# -----------------------------
# FIXED: /api/data/check (uses sqlite queries, per-user)
# -----------------------------
@app.route('/api/data/check')
@login_required
def check_data():
    user_id = session['user_id']
    conn = get_db_connection()
    cur = conn.cursor()

    # Count products belonging to user
    cur.execute('SELECT COUNT(*) FROM products WHERE user_id = ?', (user_id,))
    total_products = cur.fetchone()[0] or 0

    # Count stock_platforms for user's products (join to ensure ownership)
    cur.execute('''
        SELECT COUNT(sp.id) FROM stock_platforms sp
        JOIN products p ON sp.product_id = p.id
        WHERE p.user_id = ?
    ''', (user_id,))
    total_stock_rows = cur.fetchone()[0] or 0

    # Count sales
    cur.execute('SELECT COUNT(*) FROM sales WHERE user_id = ?', (user_id,))
    total_sales = cur.fetchone()[0] or 0

    # Count stock_transactions
    cur.execute('SELECT COUNT(*) FROM stock_transactions WHERE user_id = ?', (user_id,))
    total_tx = cur.fetchone()[0] or 0

    conn.close()

    total = int(total_products) + int(total_stock_rows) + int(total_sales) + int(total_tx)
    return jsonify({"total_data": total})


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=81, debug=True)